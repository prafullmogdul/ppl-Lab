Study use of files created by option save-temps 

1. use command save-temps options while comiplation of all program 
2. use objdump tool to read object file (explore option of objdump namely l,d,r, prefix-addresses)


